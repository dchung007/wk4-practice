function callOnTarget(func, obj1, obj2) {
  // Your code here
}


/*****************************************************************************/
/***************** DO NOT MODIFY ANYTHING UNDER THIS LINE ********************/

module.exports = callOnTarget;